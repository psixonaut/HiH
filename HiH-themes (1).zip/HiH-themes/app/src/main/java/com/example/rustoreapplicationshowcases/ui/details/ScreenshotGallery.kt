package com.example.rustoreapplicationshowcases.ui.details

class ScreenshotGallery {
}