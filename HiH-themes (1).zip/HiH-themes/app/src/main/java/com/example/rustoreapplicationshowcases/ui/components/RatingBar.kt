package com.example.rustoreapplicationshowcases.ui.components

class RatingBar {
}