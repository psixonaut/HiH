package com.example.rustoreapplicationshowcases.utils

class Extensions {
}