package com.example.rustoreapplicationshowcases.data.model

enum class SortType {
    ALPHABETICAL,
    RATING,
    DOWNLOADS
}

