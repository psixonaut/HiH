package com.example.rustoreapplicationshowcases.ui.onboarding

class OnboardingViewModel {
}