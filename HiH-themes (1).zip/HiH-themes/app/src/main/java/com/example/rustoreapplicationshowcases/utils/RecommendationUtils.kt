package com.example.rustoreapplicationshowcases.utils

class RecommendationUtils {
}