package com.example.rustoreapplicationshowcases.ui.components

class SearchBar {
}