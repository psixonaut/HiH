package com.example.rustoreapplicationshowcases.ui.components

class SkeletonLoader {
}