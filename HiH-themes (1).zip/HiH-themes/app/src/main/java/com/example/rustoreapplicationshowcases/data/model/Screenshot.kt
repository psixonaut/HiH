package com.example.rustoreapplicationshowcases.data.model

class Screenshot {
}